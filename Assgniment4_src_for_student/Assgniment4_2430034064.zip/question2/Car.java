package question2;

public abstract class Car implements Movable {
	
}
