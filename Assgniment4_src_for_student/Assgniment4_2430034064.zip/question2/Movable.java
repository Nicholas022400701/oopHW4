package question2;

public interface Movable {
	
}
