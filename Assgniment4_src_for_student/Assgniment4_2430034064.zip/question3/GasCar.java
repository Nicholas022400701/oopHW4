package question3;

public class GasCar extends Car {
	
	public static void testGasCar() {

	}
}
