package question4;

public abstract class Car implements Movable {
	
}
