package question4;

public class GasCar extends Car {

	public static void testGasCar() {

	}
}
