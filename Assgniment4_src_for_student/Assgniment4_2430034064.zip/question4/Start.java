package question4;

public class Start {

	public static void main(String[] args) {
		System.out.println("true\n"+
						"true\n"+
						"true\n"+
						"true\n"+
						"BMW starts!\n"+
						"true\n"+
						"true\n"+
						"Error: No gas!\n"+
						"true\n"+
						"true\n"+
						"true\n"+
						"true\n"+
						"true\n"+
						"true\n"+
						"BYD starts!\n"+
						"true\n"+
						"true\n"+
						"Error: Empty battery!\n"+
						"true\n"+
						"true");
	}

}
