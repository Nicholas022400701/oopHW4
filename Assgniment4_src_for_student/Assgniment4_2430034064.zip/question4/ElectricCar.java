package question4;

public class ElectricCar extends Car {
	
	public static void testElectricCar() {

	}
}
