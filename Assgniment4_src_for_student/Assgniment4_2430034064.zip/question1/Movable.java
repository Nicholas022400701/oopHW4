// This package declaration specifies the package for the class.
package question1;
// This package declaration specifies the package for the class.
public interface Movable {
	// This package declaration specifies the package for the class.
	public int s=0;
	// This package declaration specifies the package for the class.
	public int t=0;
	// This package declaration specifies the package for the class.
}
// This package declaration specifies the package for the class.